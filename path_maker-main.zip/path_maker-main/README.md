# path_generator
qgis에 사용되는 경로 생성기 플러그인 / 티맵을 만드는 sk의 open api를 사용합니다.


# 설치 방법 영상 
[![QGIS Highlighter 영상](https://img.youtube.com/vi/2Vuixsv6BUU/0.jpg)](https://www.youtube.com/watch?v=2Vuixsv6BUU)
