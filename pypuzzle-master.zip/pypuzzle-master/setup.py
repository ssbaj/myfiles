from setuptools import setup, find_packages

setup(
    name="pypuzzle",
    version="0.0.1",
    packages=find_packages(),
    install_requires=[
        "requests",
    ],
    python_requires=">=3.8",
    entry_points={
        "console_scripts": [
            "pypuzzle=pypuzzle:run",
        ],
    },
)
