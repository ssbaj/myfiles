"""유동인구.txt (+p유동인구.txt) -> 유동인구.geojson 변환."""

import json
import os

from .io_utils import load_json_flexible, run_fetch_script


def _extract_points(data):
    """[[lat, lng, count], ...] 리스트를 다양한 응답 구조에서 뽑아낸다."""
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        if "data" in data and isinstance(data["data"], list):
            return data["data"]
        page_props = data.get("pageProps")
        if isinstance(page_props, dict):
            floating = page_props.get("floatingData")
            if isinstance(floating, dict) and isinstance(floating.get("data"), list):
                return floating["data"]
    raise ValueError("유동인구 데이터에서 'pageProps.floatingData.data' 좌표 목록을 찾을 수 없습니다.")


def build_floating_geojson(source_path, script_path, out_path=None, log=None):
    """유동인구 데이터를 GeoJSON(Point FeatureCollection)으로 저장한다.

    1) 먼저 p유동인구.txt(요청 스크립트)를 실행해 실시간 데이터를 시도한다.
    2) 실패하면 원본 유동인구.txt(캐시된 JSON)를 사용한다.
    """
    log = log or (lambda msg: None)

    live_data, fail_reason = run_fetch_script(script_path)
    if live_data is not None:
        data = live_data
        log("실시간 재수집 성공 (p유동인구.txt 실행)")
    else:
        log(f"실시간 재수집 실패 -> 저장된 파일 사용. 사유: {fail_reason}")
        data = load_json_flexible(source_path)

    points = _extract_points(data)

    features = []
    for pt in points:
        if not isinstance(pt, (list, tuple)) or len(pt) < 3:
            continue
        lat, lng, count = pt[0], pt[1], pt[2]
        features.append({
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [lng, lat]},
            "properties": {"count": count},
        })

    geojson = {"type": "FeatureCollection", "features": features}

    if out_path is None:
        out_path = os.path.join(os.path.dirname(source_path) or ".", "유동인구.geojson")

    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(geojson, f, ensure_ascii=False, indent=2)

    return out_path, len(features)
