"""외부 라이브러리 없이 동작하는 표준 geohash 디코더.

퍼즐(puzzle.geovision.co.kr) 카드매출 API는 위경도 대신 geohash 문자열로
격자(cell)를 표현한다. 이 모듈은 geohash 문자열을 위경도 사각형(bbox)으로
복원해, 격자를 지도 위 폴리곤으로 그릴 수 있게 해준다.
"""

_BASE32 = "0123456789bcdefghjkmnpqrstuvwxyz"
_DECODE_MAP = {c: i for i, c in enumerate(_BASE32)}


def decode_bbox(geohash):
    """geohash 문자열 -> (lat_min, lat_max, lon_min, lon_max)."""
    lat_range = [-90.0, 90.0]
    lon_range = [-180.0, 180.0]
    is_lon = True

    for ch in geohash.strip().lower():
        idx = _DECODE_MAP[ch]
        for bit in range(4, -1, -1):
            bitval = (idx >> bit) & 1
            target = lon_range if is_lon else lat_range
            mid = (target[0] + target[1]) / 2
            if bitval:
                target[0] = mid
            else:
                target[1] = mid
            is_lon = not is_lon

    return lat_range[0], lat_range[1], lon_range[0], lon_range[1]


def decode_center(geohash):
    """geohash 문자열 -> (lat, lon) 중심 좌표."""
    lat_min, lat_max, lon_min, lon_max = decode_bbox(geohash)
    return (lat_min + lat_max) / 2, (lon_min + lon_max) / 2


def bbox_polygon_coords(geohash):
    """geohash 셀 경계를 GeoJSON Polygon 좌표(반시계 방향, 첫점=끝점)로 반환한다."""
    lat_min, lat_max, lon_min, lon_max = decode_bbox(geohash)
    return [[
        [lon_min, lat_min],
        [lon_max, lat_min],
        [lon_max, lat_max],
        [lon_min, lat_max],
        [lon_min, lat_min],
    ]]
