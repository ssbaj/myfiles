import os
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from .convert_area import build_area_geojson
from .convert_card import build_card_geojson
from .convert_floating import build_floating_geojson


class MainApp(tk.Tk):
    """프로그램 실행 시 뜨는 메인 팝업창.
    유동인구/카드매출 원본 파일(txt)을 지정하고 아이콘 버튼을 클릭하면
    GeoJSON을 생성한다."""

    def __init__(self):
        super().__init__()
        self.title("PyPuzzle - 퍼즐 상권데이터 GeoJSON 변환기")
        self.geometry("640x430")
        self.resizable(False, False)

        self.floating_data_var = tk.StringVar()
        self.card_data_var = tk.StringVar()
        self.area_data_var = tk.StringVar()

        self._build_ui()
        self._autodetect_defaults()

    def _build_ui(self):
        frame = ttk.Frame(self, padding=20)
        frame.pack(fill="both", expand=True)

        ttk.Label(frame, text="PyPuzzle", font=("Segoe UI", 15, "bold")).pack(anchor="w")
        ttk.Label(
            frame,
            text="퍼즐(puzzle.geovision.co.kr) 상권 데이터를 GeoJSON으로 변환합니다.",
            foreground="#555",
        ).pack(anchor="w", pady=(0, 15))

        self._add_file_row(frame, "유동인구 데이터 (유동인구.txt)", self.floating_data_var)
        ttk.Button(
            frame, text="🚶 유동인구 GeoJSON 생성", command=self.generate_floating,
        ).pack(fill="x", pady=(4, 16), ipady=8)

        ttk.Separator(frame).pack(fill="x", pady=(0, 16))

        self._add_file_row(frame, "카드매출 데이터 (카드매출.txt)", self.card_data_var)
        ttk.Button(
            frame, text="💳 카드매출 GeoJSON 생성", command=self.generate_card,
        ).pack(fill="x", pady=(4, 16), ipady=8)

        ttk.Separator(frame).pack(fill="x", pady=(0, 16))

        self._add_file_row(frame, "상권 데이터 (상권.txt)", self.area_data_var)
        ttk.Button(
            frame, text="🏢 상권 GeoJSON 생성", command=self.generate_area,
        ).pack(fill="x", pady=(4, 16), ipady=8)

        ttk.Button(frame, text="닫기", command=self.destroy).pack(fill="x", pady=(10, 0), ipady=6)

    def _add_file_row(self, parent, label, var):
        row = ttk.Frame(parent)
        row.pack(fill="x", pady=3)
        ttk.Label(row, text=label, width=32, anchor="w").pack(side="left")
        ttk.Entry(row, textvariable=var).pack(side="left", fill="x", expand=True, padx=(0, 6))
        ttk.Button(row, text="찾아보기", command=lambda: self._browse(var)).pack(side="left")

    @staticmethod
    def _browse(var):
        path = filedialog.askopenfilename(filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
        if path:
            var.set(path)

    def _autodetect_defaults(self):
        """C:/dataPy 등 흔히 쓰는 위치에 정해진 이름의 파일이 있으면 자동으로 채워준다."""
        for base in ("C:/dataPy", "c:/dataPy"):
            if os.path.isdir(base):
                self._set_if_exists(self.floating_data_var, os.path.join(base, "유동인구.txt"))
                self._set_if_exists(self.card_data_var, os.path.join(base, "카드매출.txt"))
                self._set_if_exists(self.area_data_var, os.path.join(base, "상권.txt"))
                break

    @staticmethod
    def _set_if_exists(var, path):
        if os.path.isfile(path) and not var.get():
            var.set(path)

    def generate_floating(self):
        data_path = self.floating_data_var.get().strip()
        if not data_path or not os.path.isfile(data_path):
            messagebox.showwarning("입력 확인", "유동인구.txt 파일을 지정해주세요.")
            return

        try:
            out_path, count = build_floating_geojson(data_path, None)
        except Exception as e:
            messagebox.showerror("오류", f"유동인구 GeoJSON 생성 중 오류가 발생했습니다:\n{e}")
            return

        messagebox.showinfo("완료", f"유동인구.geojson 생성 완료\n\n{out_path}\n지점 수: {count}")

    def generate_card(self):
        data_path = self.card_data_var.get().strip()
        if not data_path or not os.path.isfile(data_path):
            messagebox.showwarning("입력 확인", "카드매출.txt 파일을 지정해주세요.")
            return

        try:
            out_path, count = build_card_geojson(data_path, None)
        except Exception as e:
            messagebox.showerror("오류", f"카드매출 GeoJSON 생성 중 오류가 발생했습니다:\n{e}")
            return

        messagebox.showinfo("완료", f"카드매출.geojson 생성 완료\n\n{out_path}\n격자 수: {count}")

    def generate_area(self):
        data_path = self.area_data_var.get().strip()
        if not data_path or not os.path.isfile(data_path):
            messagebox.showwarning("입력 확인", "상권.txt 파일을 지정해주세요.")
            return

        try:
            out_path, count = build_area_geojson(data_path)
        except Exception as e:
            messagebox.showerror("오류", f"상권 GeoJSON 생성 중 오류가 발생했습니다:\n{e}")
            return

        messagebox.showinfo("완료", f"상권.geojson 생성 완료\n\n{out_path}\n상권 수: {count}")
