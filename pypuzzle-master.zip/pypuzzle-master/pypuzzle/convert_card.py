"""카드매출.txt (+p카드매출.txt) -> 카드매출.geojson 변환."""

import json
import os

from .geohash_util import bbox_polygon_coords
from .io_utils import load_json_flexible, run_fetch_script


def _extract_records(data):
    """geohash 단위 카드매출 레코드 리스트를 다양한 응답 구조에서 뽑아낸다."""
    if isinstance(data, list):
        return data
    if isinstance(data, dict) and isinstance(data.get("data"), list):
        return data["data"]
    raise ValueError("카드매출 데이터에서 geohash 레코드 목록을 찾을 수 없습니다.")


def build_card_geojson(source_path, script_path, out_path=None, log=None):
    """카드매출 데이터를 GeoJSON(geohash 격자 Polygon FeatureCollection)으로 저장한다.

    1) 먼저 p카드매출.txt(요청 스크립트)를 실행해 실시간 데이터를 시도한다.
    2) 실패하면 원본 카드매출.txt(캐시된 JSON)를 사용한다.
    """
    log = log or (lambda msg: None)

    live_data, fail_reason = run_fetch_script(script_path)
    if live_data is not None:
        data = live_data
        log("실시간 재수집 성공 (p카드매출.txt 실행)")
    else:
        log(f"실시간 재수집 실패 -> 저장된 파일 사용. 사유: {fail_reason}")
        data = load_json_flexible(source_path)

    records = _extract_records(data)

    features = []
    for rec in records:
        geohash = rec.get("geohash")
        if not geohash:
            continue
        try:
            coords = bbox_polygon_coords(geohash)
        except KeyError:
            continue

        properties = {k: v for k, v in rec.items() if k != "geohash"}
        properties["geohash"] = geohash

        features.append({
            "type": "Feature",
            "geometry": {"type": "Polygon", "coordinates": coords},
            "properties": properties,
        })

    geojson = {"type": "FeatureCollection", "features": features}

    if out_path is None:
        out_path = os.path.join(os.path.dirname(source_path) or ".", "카드매출.geojson")

    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(geojson, f, ensure_ascii=False, indent=2)

    return out_path, len(features)
