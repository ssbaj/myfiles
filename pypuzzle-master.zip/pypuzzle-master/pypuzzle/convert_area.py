"""상권.txt -> 상권.geojson 변환."""

import json
import os

from .io_utils import load_json_flexible


def _extract_areas(data):
    """상권(혼잡도) 목록을 응답 구조에서 뽑아낸다."""
    if isinstance(data, list):
        return data
    if isinstance(data, dict) and isinstance(data.get("contents"), list):
        return data["contents"]
    raise ValueError("상권 데이터에서 'contents' 목록을 찾을 수 없습니다.")


def build_area_geojson(source_path, out_path=None, log=None):
    """상권 데이터를 GeoJSON(Polygon FeatureCollection)으로 저장한다."""
    log = log or (lambda msg: None)

    data = load_json_flexible(source_path)
    areas = _extract_areas(data)

    features = []
    for area in areas:
        detail = area.get("areaMetaDetail") or {}
        geometry = detail.get("geometry")
        if not geometry:
            continue

        rltm = area.get("rltm") or {}
        properties = {
            "areaId": area.get("areaId"),
            "areaName": area.get("areaName"),
            "congestion": rltm.get("congestion"),
            "congestionLevel": rltm.get("congestionLevel"),
            "datetime": rltm.get("datetime"),
            "repLat": detail.get("repLat"),
            "repLng": detail.get("repLng"),
            "areaM2": detail.get("areaM2"),
        }

        features.append({
            "type": "Feature",
            "geometry": geometry,
            "properties": properties,
        })

    geojson = {"type": "FeatureCollection", "features": features}

    if out_path is None:
        out_path = os.path.join(os.path.dirname(source_path) or ".", "상권.geojson")

    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(geojson, f, ensure_ascii=False, indent=2)

    log(f"상권 GeoJSON 생성 완료: {out_path} ({len(features)}개 상권)")
    return out_path, len(features)
