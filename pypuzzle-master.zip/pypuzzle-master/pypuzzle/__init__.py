from .app import MainApp
from .convert_floating import build_floating_geojson
from .convert_card import build_card_geojson


def run():
    """PyPuzzle GUI를 실행한다."""
    app = MainApp()
    app.mainloop()
