"""파일 로딩 및 'p파일(요청 스크립트)' 재실행을 담당하는 공용 유틸리티."""

import json
import socket

_ENCODINGS = ("utf-8-sig", "utf-8", "cp949", "euc-kr")


def load_json_flexible(path):
    """인코딩을 몰라도(UTF-8 / UTF-8 BOM / CP949) JSON 파일을 읽어들인다."""
    last_err = None
    for enc in _ENCODINGS:
        try:
            with open(path, "r", encoding=enc) as f:
                return json.load(f)
        except (UnicodeDecodeError, json.JSONDecodeError) as e:
            last_err = e
            continue
    raise ValueError(f"'{path}' 파일을 알려진 인코딩({', '.join(_ENCODINGS)})으로 읽을 수 없습니다: {last_err}")


def run_fetch_script(script_path, timeout=6):
    """p유동인구.txt / p카드매출.txt 같은 requests 호출 스크립트를 실행해
    최신 데이터를 실시간으로 재수집한다.

    스크립트는 마지막에 `response = requests.get(...)` 형태로 끝나므로,
    실행 후 네임스페이스에서 `response` 변수를 꺼내 JSON으로 반환한다.
    쿠키 만료/네트워크 오류 등 어떤 이유로든 실패하면 (None, 사유 문자열)을 반환하고,
    호출 측이 저장된 원본 파일로 대체(fallback)할 수 있게 한다.
    """
    if not script_path:
        return None, "수집 스크립트가 지정되지 않았습니다."

    try:
        with open(script_path, "r", encoding="utf-8-sig") as f:
            source = f.read()
    except OSError as e:
        return None, f"스크립트 파일을 열 수 없습니다: {e}"

    namespace = {}
    old_timeout = socket.getdefaulttimeout()
    try:
        socket.setdefaulttimeout(timeout)
        exec(compile(source, script_path, "exec"), namespace)
    except Exception as e:  # noqa: BLE001 - 실행 실패는 전부 fallback 사유로 취급
        return None, f"스크립트 실행 중 오류: {e}"
    finally:
        socket.setdefaulttimeout(old_timeout)

    response = namespace.get("response")
    if response is None:
        return None, "스크립트에 'response' 변수가 없습니다."

    status = getattr(response, "status_code", None)
    if status != 200:
        return None, f"서버 응답 실패 (status={status}). 쿠키/세션이 만료되었을 수 있습니다."

    try:
        return response.json(), None
    except ValueError as e:
        return None, f"응답을 JSON으로 해석할 수 없습니다: {e}"
