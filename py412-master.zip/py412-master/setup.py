from setuptools import setup, find_packages

setup(
    name="py412",
    version="0.0.8",
    packages=find_packages(),
    install_requires=[
        "pandas",
        "openpyxl",
        "chardet",
        "pyreadstat",
        "requests",
    ],
    python_requires=">=3.8",
)